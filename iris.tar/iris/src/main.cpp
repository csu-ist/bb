/*
 * main.cpp
 *
 *  Created on: 2017年7月7日
 *      Author: Derek
 */

#include <iostream>
#include <ctime>
#include "tensorflow/core/public/session.h"
#include "tensorflow/core/platform/env.h"
#include "dpc_model_loader.h"

using namespace tensorflow;

int main(int argc, char* argv[]) {
    clock_t start_time, end_time;
    start_time = clock();
    if (argc != 2) {
        std::cout << "WARNING: Input Args missing" << std::endl;
        return 0;
    }
    std::string model_path = argv[1];  // Model_path *.pb file

    // TensorName pre-defined in python file, Need to extract values from tensors
    std::string input_tensor_name = "inputdata";
    std::string output_tensor_name = "conv_5/BiasAdd";

    // Create New Session
    Session* session;
    Status status = NewSession(SessionOptions(), &session);
    if (!status.ok()) {
        std::cout << status.ToString() << "\n";
        return 0;
    }

    // Create prediction demo
    tf_model::ANNModelLoader model;  //Create demo for prediction
    if (0 != model.load(session, model_path)) {
        std::cout << "Error: Model Loading failed..." << std::endl;
        return 0;
    }

    // Define Input tensor and Feature Adapter
    // Demo example: [1.0, 1.0, 1.0, 1.0, 1.0] for Iris Example, including bias
    int buffer_size = 2500;
    //std::vector<float> input;
    float* input=new float[buffer_size];
    for (int i = 0; i < buffer_size; i++){
        input[i]=0.5;
    }
    //for (int i = 0; i < buffer_size; i++) {
    //    input.push_back(0.5);
    //}

    // New Feature Adapter to convert vector to tensors dictionary
    tf_model::ANNFeatureAdapter input_feat;
    input_feat.assign(input_tensor_name, input);   //Assign vec<float> to tensor
    delete[] input;
    
    // Make New Prediction
    float* prediction = new float[buffer_size];
    start_time = clock();
    if (0 != model.predict(session, input_feat, output_tensor_name, prediction)) {
        std::cout << "WARNING: Prediction failed..." << std::endl;
    }

    end_time = clock();
    std::cout << "Total time:" <<((double)(end_time-start_time)/CLOCKS_PER_SEC)*1000<<" ms"<<std::endl;
    std::cout << "Output Prediction Value:" << std::endl;
    for (int i = 0; i < buffer_size; i++){
        //std::cout << prediction[i]<< ", ";
    }
    delete[] prediction;
	return 0;
}
